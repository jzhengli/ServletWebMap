create function st_approxsummarystats(rastertable text, rastercolumn text, nband integer, sample_percent double precision) returns summarystats
  stable
  strict
  parallel safe
  language sql
as
$$
SELECT public._ST_summarystats($1, $2, $3, TRUE, $4)
$$;

alter function st_approxsummarystats(text, text, integer, double precision) owner to postgres;

