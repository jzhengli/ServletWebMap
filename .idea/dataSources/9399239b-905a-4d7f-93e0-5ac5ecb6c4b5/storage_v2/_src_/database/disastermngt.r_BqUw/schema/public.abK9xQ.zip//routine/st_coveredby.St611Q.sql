create function st_coveredby(geom1 geometry, geom2 geometry) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT $1 OPERATOR(public.@) $2 AND public._ST_CoveredBy($1,$2)
$$;

comment on function st_coveredby(geometry, geometry) is 'args: geomA, geomB - Returns 1 (TRUE) if no point in Geometry/Geography A is outside Geometry/Geography B';

alter function st_coveredby(geometry, geometry) owner to postgres;

