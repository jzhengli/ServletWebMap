create function st_approxsummarystats(rastertable text, rastercolumn text, sample_percent double precision) returns summarystats
  stable
  strict
  parallel safe
  language sql
as
$$
SELECT public._ST_summarystats($1, $2, 1, TRUE, $3)
$$;

alter function st_approxsummarystats(text, text, double precision) owner to postgres;

