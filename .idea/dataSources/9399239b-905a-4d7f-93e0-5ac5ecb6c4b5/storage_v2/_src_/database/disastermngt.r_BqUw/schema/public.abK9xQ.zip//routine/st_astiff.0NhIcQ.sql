create function st_astiff(rast raster, nbands integer[], options text[] DEFAULT NULL::text[], srid integer DEFAULT NULL::integer) returns bytea
  immutable
  parallel safe
  language sql
as
$$
SELECT st_astiff(st_band($1, $2), $3, $4)
$$;

comment on function st_astiff(raster, integer[], text[], integer) is 'args: rast, nbands, options, srid=sameassource - Return the raster selected bands as a single TIFF image (byte array). If no band is specified or any of specified bands does not exist in the raster, then will try to use all bands.';

alter function st_astiff(raster, integer[], text[], integer) owner to postgres;

