create function st_intersects(text, text) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT public.ST_Intersects($1::public.geometry, $2::public.geometry);
$$;

alter function st_intersects(text, text) owner to postgres;

