create function st_resize(rast raster, width integer, height integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public._ST_gdalwarp($1, $4, $5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, abs($2), abs($3))
$$;

comment on function st_resize(raster, integer, integer, text, double precision) is 'args: rast, width, height, algorithm=NearestNeighbor, maxerr=0.125 - Resize a raster to a new width/height';

alter function st_resize(raster, integer, integer, text, double precision) owner to postgres;

