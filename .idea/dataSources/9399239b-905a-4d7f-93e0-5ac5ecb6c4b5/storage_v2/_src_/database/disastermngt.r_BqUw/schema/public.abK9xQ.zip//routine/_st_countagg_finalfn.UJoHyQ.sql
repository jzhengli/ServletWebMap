create function "_st_countagg_finalfn"(agg agg_count) returns bigint
  immutable
  parallel safe
  language plpgsql
as
$$
BEGIN
		IF agg IS NULL THEN
			RAISE EXCEPTION 'Cannot count coverage';
		END IF;

		RETURN agg.count;
	END;

$$;

alter function "_st_countagg_finalfn"(agg_count) owner to postgres;

